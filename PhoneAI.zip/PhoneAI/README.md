# Phone AI (Android + Claude API)

1. Android Studio में इस फोल्डर को Open करें (Gradle sync होने दें)।
2. फोन पर USB debugging चालू करके Run दबाएँ, या Build > Build APK(s) से APK बनाएँ।
3. ऐप खोलें -> API key डालें (console.anthropic.com से)।
4. "Accessibility चालू करें" दबाएँ -> Phone AI चुनें -> ON करें।
   (Android 13+ पर अगर सेटिंग धूसर हो, तो App info > तीन बिंदु > "Allow restricted settings")
5. 🎤 दबाकर बोलें: "WhatsApp पर Rahul को मैसेज करो कि मैं 5 बजे आऊँगा"।

Config.kt में आप अनुमति वाली ऐप्स की सूची बदल सकते हैं।
