package com.example.phoneai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var log: TextView
    private lateinit var keyInput: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var client: ClaudeClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        keyInput = EditText(this).apply {
            hint = "Claude API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getSharedPreferences("p", MODE_PRIVATE).getString("key", ""))
        }
        val a11yBtn = Button(this).apply {
            text = "1) Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val micBtn = Button(this).apply {
            text = "🎤 बोलिए"
            textSize = 20f
            setOnClickListener { startListening() }
        }
        log = TextView(this).apply { textSize = 16f; gravity = Gravity.START }
        val scroll = ScrollView(this).apply { addView(log) }

        root.addView(keyInput)
        root.addView(a11yBtn)
        root.addView(micBtn)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        requestPermissions(
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS), 1
        )
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    private fun say(who: String, text: String) {
        runOnUiThread { log.append("$who: $text\n\n") }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "r")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("ऐप", "माइक की अनुमति दें"); return
        }
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) { say("ऐप", "पहले API key डालें"); return }
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("key", key).apply()
        if (client == null) client = ClaudeClient(key)

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) handle(t)
                }
                override fun onError(error: Int) { say("ऐप", "सुन नहीं पाया (error $error)") }
                override fun onReadyForSpeech(p: Bundle?) { say("ऐप", "सुन रहा हूँ...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer?.startListening(i)
    }

    private fun handle(userText: String) {
        say("आप", userText)
        Thread {
            try {
                val res = client!!.ask(userText)
                val reply = res.optString("reply")
                val actions = res.optJSONArray("actions") ?: JSONArray()
                say("AI", reply)
                speak(reply)
                if (actions.length() > 0) runOnUiThread { confirmAndRun(reply, actions) }
            } catch (e: Exception) {
                say("Error", e.message ?: "unknown")
            }
        }.start()
    }

    private fun confirmAndRun(reply: String, actions: JSONArray) {
        val svc = PhoneAccessibilityService.instance
        if (svc == null) { say("ऐप", "Accessibility सर्विस चालू नहीं है"); return }

        var sends = false
        for (i in 0 until actions.length()) {
            if (actions.getJSONObject(i).getString("type") == "whatsapp_message") sends = true
        }
        val run = {
            svc.runActions(actions) { r -> say("ऐप", r); speak(r) }
        }
        if (sends) {
            AlertDialog.Builder(this)
                .setTitle("मैसेज भेजना है?")
                .setMessage(actions.toString(2))
                .setPositiveButton("हाँ भेजो") { _, _ -> run() }
                .setNegativeButton("रद्द", null)
                .show()
        } else run()
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
