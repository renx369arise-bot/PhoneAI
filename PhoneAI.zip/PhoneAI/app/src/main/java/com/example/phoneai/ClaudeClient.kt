package com.example.phoneai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeClient(private val apiKey: String) {

    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val history = JSONArray()

    // आप यहाँ MODEL बदल सकते हैं
    private val model = "claude-sonnet-5-5"

    private val system = """
You are a voice assistant that controls the user's Android phone. The user speaks Hindi, English or Hinglish.
ALWAYS reply with ONLY a JSON object, no other text, in this format:
{"reply":"short spoken answer in the user's language","actions":[ ... ]}
"actions" can be empty (for normal questions). Available actions:
{"type":"open_app","package":"com.whatsapp"}
{"type":"whatsapp_message","contact":"contact name as saved in phone","text":"message"}
{"type":"tap_text","text":"visible text or label to tap"}
{"type":"type_text","text":"text to type in focused field"}
{"type":"scroll_down"}
{"type":"back"}
{"type":"home"}
{"type":"wait","ms":1500}
Allowed packages: ${Config.ALLOWED_PACKAGES.joinToString(", ")}.
Never use any other package. Keep "reply" short (1-2 sentences). Do not invent contacts.
""".trimIndent()

    fun ask(userText: String): JSONObject {
        history.put(JSONObject().put("role", "user").put("content", userText))
        while (history.length() > 20) history.remove(0)

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1000)
            .put("system", system)
            .put("messages", history)

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw RuntimeException("API error ${resp.code}: $raw")
            val text = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
            history.put(JSONObject().put("role", "assistant").put("content", text))
            return parse(text)
        }
    }

    private fun parse(text: String): JSONObject {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        return try {
            JSONObject(text.substring(s, e + 1))
        } catch (ex: Exception) {
            JSONObject().put("reply", text).put("actions", JSONArray())
        }
    }
}
