package com.example.phoneai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class PhoneAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: PhoneAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun runActions(actions: JSONArray, onDone: (String) -> Unit) {
        Thread {
            var result = "ठीक है, हो गया।"
            try {
                for (i in 0 until actions.length()) {
                    val a = actions.getJSONObject(i)
                    execute(a)
                }
            } catch (e: Exception) {
                result = "कुछ गड़बड़ हुई: ${e.message}"
            }
            onDone(result)
        }.start()
    }

    private fun execute(a: JSONObject) {
        when (a.getString("type")) {
            "open_app" -> openApp(a.getString("package"))
            "whatsapp_message" -> whatsappMessage(a.getString("contact"), a.getString("text"))
            "tap_text" -> {
                if (!tapText(a.getString("text"))) throw RuntimeException("'${a.getString("text")}' नहीं मिला")
                Thread.sleep(800)
            }
            "type_text" -> { typeText(a.getString("text")); Thread.sleep(500) }
            "scroll_down" -> { scroll(); Thread.sleep(600) }
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); Thread.sleep(500) }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); Thread.sleep(500) }
            "wait" -> Thread.sleep(a.optLong("ms", 1000).coerceIn(0, 10000))
        }
    }

    private fun openApp(pkg: String) {
        if (pkg !in Config.ALLOWED_PACKAGES) throw RuntimeException("$pkg की अनुमति नहीं है")
        val intent = packageManager.getLaunchIntentForPackage(pkg)
            ?: throw RuntimeException("$pkg इंस्टॉल नहीं है")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        Thread.sleep(2000)
    }

    private fun whatsappMessage(contact: String, text: String) {
        val phone = findPhone(contact) ?: throw RuntimeException("'$contact' कॉन्टैक्ट्स में नहीं मिला")
        val uri = Uri.parse("https://wa.me/$phone?text=${Uri.encode(text)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        Thread.sleep(3500)
        val sent = tapText("Send") || tapText("भेजें")
        if (!sent) throw RuntimeException("Send बटन नहीं मिला")
        Thread.sleep(800)
    }

    private fun findPhone(name: String): String? {
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        cursor.use {
            if (!it.moveToFirst()) return null
            var n = it.getString(0).filter { c -> c.isDigit() || c == '+' }.removePrefix("+")
            if (n.length == 10) n = Config.DEFAULT_COUNTRY_CODE + n
            return n
        }
    }

    private fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            var n: AccessibilityNodeInfo? = node
            while (n != null) {
                if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                n = n.parent
            }
        }
        return false
    }

    private fun typeText(text: String) {
        val root = rootInActiveWindow ?: throw RuntimeException("स्क्रीन नहीं पढ़ पाया")
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: throw RuntimeException("टाइप करने की जगह नहीं मिली")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scroll() {
        val root = rootInActiveWindow ?: return
        findScrollable(root)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }
}
