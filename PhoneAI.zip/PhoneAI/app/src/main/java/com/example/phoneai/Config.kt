package com.example.phoneai

object Config {
    // सिर्फ़ यही ऐप्स कंट्रोल होंगी। और जोड़ना हो तो यहाँ package name जोड़ें।
    val ALLOWED_PACKAGES = listOf(
        "com.whatsapp",
        "com.google.android.youtube",
        "com.android.chrome",
        "com.google.android.apps.maps",
        "com.google.android.dialer",
        "com.android.settings"
    )

    // 10 अंकों वाले नंबर के आगे यह country code लगेगा (भारत = 91)
    const val DEFAULT_COUNTRY_CODE = "91"
}
